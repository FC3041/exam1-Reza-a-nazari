using System.Diagnostics;
using System.Security.Cryptography.X509Certificates;
using System.IO;



namespace Exam1;

public class Q1_Add
{

    public static int Add(int x , int y)
    {
        return x+y ;
    }


}

public class Basics
{
    public static void Q2MultiplyAndReset(ref int x , ref int y)
    {
        x = x * y ;
        y = y / y ;
    }

    
    public static void Q3Increment( Type1 t1 ,  Type2 t2)
    {
        int z =  t2.Count +1000 ;
        t2.Count = z ;
        

    }



    public class  Type1 
    {
        public int Count{get;set;}
        
    }

    public class Type2
    {
        public int Count {get;set;}

    }



    // public class Q5TryCatchFinally
    // {
    //     public bool Boooool {get;set;}

    //     List<string> Mylist {get;set;}

    //     public Q5TryCatchFinally(bool b1 , List<string> s1 , bool b2)
    //     {
    //         Boooool = b1 ;

    //         Mylist = s1 ;

    //         Boooool = b2 ;


    //     }
    // }


    public static void Q5TryCatchFinally(bool v, List<string> log)
    {
        
        try
        {
            int x = 5 ;
            int y = 20 ;
            if(v==true)
                int.Parse("a");
            
        }
        catch
        {
            if(v == true)
                throw ;
            
            
        }
        finally
        {
            int x ;
            
        }
    }

    public static void Q5TryCatchFinally(bool v1, List<string> list, bool v2)
    {
        if(v1==true && v2 ==true)
            throw new InvalidOperationException();
    }
}





public class Q4Person
{
    public string Name{get;set;}
    public int Age{get;set;}

    public Q4Person(string fname , int sen)
    {
        Name = fname ;
        Age = sen ;
    }

    public string Introduce()
    {
        return $"Hello, my name is {Name} and I am {Age} years old.";
    }



}


public interface IShape
{
 
    public double GetArea();
    public double GetPerimeter();
    public double Q7TotalArea();


}

public class Q7Rectangle : IShape
{
    public double v1;
    public double v2;

    public Q7Rectangle(double V1, double V2)
    {
        this.v1 = V1;
        this.v2 = V2;
    }

    public double GetArea()
    {
        return v1 * v2 ;
    }

    public double GetPerimeter()
    {
        return (v1+v2)*2 ;
    }

    public double Q7TotalArea()
    {
        throw new NotImplementedException();
    }
}


public class Q7Circle : IShape
{
    public double r;

    public Q7Circle(double R)
    {
        this.r = R;
    }

    public double GetArea()
    {
        return Math.PI * r * r;
    }

    public double GetPerimeter()
    {
        return Math.PI * 2  * r ;
    }

    public double Q7TotalArea()
    {
        throw new NotImplementedException();
    }
}



// public class ShapeUtils :IShape
// {
//     public double GetArea()
//     {
//         throw new NotImplementedException();
//     }

//     public double GetPerimeter()
//     {
//         throw new NotImplementedException();
//     }



//     double IShape.Q7TotalArea(IShape shape)
//     {
//         return a
//     }
// }




